# TOOL946-自评能力项界面增加能力要求筛选

## 关联工单信息

[TOOL946-自评能力项界面增加能力要求筛选](http://10.60.45.229:8888/browse/TOOL-946)

## 文档更新说明

| 版本 | 更新状态 | 修改日期 | 更新说明 | 变更人 |
| --- | --- | --- | --- | --- |
| 1.0.0 | C | 2023/7/12 | C：开发设计文档的初次编写 | 马振宇 |
| 1.0.1 | A | 2023/7/19 | A: 新增流程设计 | 马振宇 |


更新状态，用字母表示：

> C——创建，A——增加，M——修改，D——删除



## 关键词解释
| 能力要求 | 对能力掌握的要求，包含必备，优先，可选等 |
| --- | --- |
| 自评界面 | 员工对自己能力是否掌握进行评价的界面 |


## 功能需求
自评能力项界面增加能力要求筛选

## 前端页面展示
![](.\images\页面.png)

## 流程设计

F1. 前端请求中新增能力要求相关参数
- 不携带该参数，查询所有能力要求的明细项
- 携带一个或多个参数，查询所有符合能力要求的明细项

F2. 后端接收请求并调用SQL进行查询(中间无多余流程)

F3. SQL包含的流程
- 能力明细表(capacity_value)通过能力项ID(capacity_id)内连接能力项表(capacity)
- 使用当前登录用户的成员ID(member_id)内连接用户表(user)
- 通过user的用户ID(user.member_id)内连接用户角色表(member_role 包含用户的角色信息:前端，后端，测试等)
- 通过能力明细项ID内连接能力明细项角色和重要性表(capacity_role_importance)
- 左外链接能力项种类表(capacity_type)通过(capacity.capacity_type = capacity_type.id)，部分能力项可能还没有进行分类capacity_type存在null所以使用左外链接
- 查询需要的字段信息

```sql
                capacity_value.id AS id,
                capacity_value.capacity_id AS capacityId,
                capacity.name AS capacityName, capacity_value.id AS capacityDetailId,
                capacity_value.info AS capacityDetailName,
                capacity_value.weight_info AS capacityDetailWeightInfo,
                capacity_value.info_url AS capacityDetailInfoUrl,
                capacity_value.value,
                user.member_id AS appraiseeId,
                cri.capacity_importance_code AS capacityImportanceCode,
                cri.role_code AS capacityRoleCode, capacity.capacity_type,
                capacity_type.name AS capacityTypeName
```
- 将查询到的信息用作子查询左外链接员工自评表(employee_appraise),链接条件使用三个字段appraisee_id，capacity_detail_id，capacity_id
- 查询子查询中的所有字段，新增查询字段(employee_appraise.is_master)，因为员工自评表(employee_appraise)中的数据并不完全，当员工没有自评过某一能力项时左外链接后的数据为NULL，

将NULL值作为0处理。

- 将第二个查询再作为子查询使用SELECT *查询所有数据
- 对需要筛选的条件使用where语句判断，例如能力项要求，添加where capacity_importance_code in（...）

```sql
-- SELECT T.*, IFNULL(employee_appraise.is_master, 0) AS isMaster FROM (...)
-- 这个子查询从另一个子查询 (...) 中获取结果，并在每行结果的基础上添加一个名为 isMaster 的列  
SELECT * FROM (
	SELECT T.*, 
	IFNULL(employee_appraise.is_master, 0) AS isMaster 
	FROM (
		SELECT DISTINCT 
		capacity_value.id AS id,
		capacity_value.capacity_id AS capacityId,
		capacity.name AS capacityName, capacity_value.id AS capacityDetailId,
		capacity_value.info AS capacityDetailName,
		capacity_value.weight_info AS capacityDetailWeightInfo,
		capacity_value.info_url AS capacityDetailInfoUrl,
		capacity_value.value,
		user.member_id AS appraiseeId,
		cri.capacity_importance_code AS capacityImportanceCode,
		cri.role_code AS capacityRoleCode, capacity.capacity_type,
		capacity_type.name AS capacityTypeName 
		FROM capacity_value
		INNER JOIN capacity ON capacity_value.capacity_id = capacity.id 
		INNER JOIN user ON user.member_id = 223 
		INNER JOIN member_role mr ON user.member_id = mr.member_id 
    INNER JOIN member mb ON mb.id = user.member_id 
		INNER JOIN capacity_role_importance cri ON mr.role_code = cri.role_code 
			AND capacity_value.id = cri.capacity_value_id 
			AND (cri.position = mb.position OR cri.position = '') 
	LEFT JOIN capacity_type ON capacity.capacity_type = capacity_type.id) T 
	LEFT JOIN employee_appraise ON T.capacityId = employee_appraise.capacity_id
		AND T.capacityDetailId = employee_appraise.capacity_detail_id 
		AND appraiseeId = employee_appraise.appraisee_id) T2 LIMIT 50


```


## 新增部分

1. 要添加能力重要性的筛选，只要在最小的子查询中添加where语句即可。

## 相关接口
[http://localhost:8080/api/PERFORMANCE-MANAGE/appraise/listAll](http://localhost:8080/api/PERFORMANCE-MANAGE/appraise/listAll)
